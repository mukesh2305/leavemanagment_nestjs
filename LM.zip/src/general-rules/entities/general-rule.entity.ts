export class GeneralRule {}
