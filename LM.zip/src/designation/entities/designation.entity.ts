export class Designation {}
