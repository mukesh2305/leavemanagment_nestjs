export class CategoryLeave {

    
}
