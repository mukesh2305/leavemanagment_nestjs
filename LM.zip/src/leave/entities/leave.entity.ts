export class Leave {}
