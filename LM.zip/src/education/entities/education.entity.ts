export class Education {}
