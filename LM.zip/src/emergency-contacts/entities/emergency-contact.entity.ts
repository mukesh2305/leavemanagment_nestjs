export class EmergencyContact {}
