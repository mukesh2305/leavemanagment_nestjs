export class Holiday {}
